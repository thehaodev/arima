from __future__ import annotations

import pandas as pd

from src.plotting import create_line_figure


def create_time_series_figure(
    dataframe: pd.DataFrame,
    time_column: str,
    value_column: str,
    title: str,
) -> object:
    """Build a line chart for a time series."""
    return create_line_figure(
        x_values=dataframe[time_column],
        y_values=dataframe[value_column],
        name=value_column,
        title=title,
        xaxis_title=time_column,
        yaxis_title=value_column,
    )


def apply_differencing(
    dataframe: pd.DataFrame,
    time_column: str,
    value_column: str,
    order: int,
) -> pd.DataFrame:
    """Return the original or differenced time series."""
    if order not in (0, 1, 2):
        raise ValueError("Chỉ hỗ trợ sai phân bậc 0, 1 hoặc 2.")

    result_df = dataframe[[time_column, value_column]].copy()
    result_df[value_column] = pd.to_numeric(result_df[value_column], errors="coerce")
    result_df = result_df.dropna(subset=[value_column]).reset_index(drop=True)

    if result_df.empty:
        raise ValueError("Cột giá trị không có dữ liệu số hợp lệ để vẽ biểu đồ hoặc sai phân.")

    if order > 0:
        result_df[value_column] = result_df[value_column].diff(periods=order)
        result_df = result_df.dropna(subset=[value_column]).reset_index(drop=True)

    if result_df.empty:
        raise ValueError("Không còn dữ liệu sau khi sai phân. Hãy kiểm tra số dòng của chuỗi.")

    return result_df
